const questions = [
    {
        text: "คุณชอบขนมที่มีเนื้อสัมผัสแบบไหนมากที่สุด?",
        options: {
            A: "กรอบ สนุกกับการเคี้ยวเพลิน ๆ",
            B: "หนึบหนับ เคี้ยวแล้วรู้สึกสนุก",
            C: "เหนียวหนึบ ยืดหยุ่น เคี้ยวได้นาน",
            D: "ละลายในปาก ไม่ต้องเคี้ยวเยอะ"
        }
    },
    {
        text: "ถ้าให้เลือกขนมจากรสชาติ คุณชอบแบบไหนที่สุด?",
        options: {
            A: "หวาน นุ่มละมุน",
            B: "เปรี้ยวจี๊ดสะใจ",
            C: "เค็ม ๆ มัน ๆ รสชาติเข้มข้น",
            D: "ซ่า สดชื่น"
        }
    },
    {
        text: "เวลากินขนม คุณชอบให้มัน…",
        options: {
            A: "มีไส้ข้างใน หรือเคลือบอะไรสักอย่าง",
            B: "เป็นเยลลี่ หรือเจลาตินเคี้ยวหนุบหนับ",
            C: "เป็นลูกอมเล็ก ๆ ค่อย ๆ ละลาย",
            D: "เป็นหมากฝรั่ง เคี้ยวได้เรื่อย ๆ"
        }
    }
];

const results = {
    A: "ขนมกรุบกรอบ / เคลือบไส้: เหมาะกับขนมอย่าง ปูไทย, ขนมปังจิ้มช็อกโกแลต",
    B: "ขนมหนุบหนับ / เคี้ยวสนุก: เหมาะกับขนมอย่าง กัมมี่ฟรุตตี้, จอลลี่สติ๊ก",
    C: "ขนมอมเล่นได้นาน / มีลูกเล่นพิเศษ: เหมาะกับขนมอย่าง ลูกอมเป๊าะแป๊ะ, แหวนอมยิ้ม",
    D: "ขนมสดชื่น / หมากฝรั่งเคี้ยวได้นาน: เหมาะกับขนมอย่าง โคล่าอัดเม็ด, ลูกอมบ๊วย"
};

let currentQuestion = 0;
let answers = { A: 0, B: 0, C: 0, D: 0 };

function startQuiz() {
    document.getElementById("start-screen").style.display = "none";
    document.getElementById("quiz-screen").style.display = "block";
    loadQuestion();
}

function loadQuestion() {
    const questionData = questions[currentQuestion];
    document.getElementById("question-text").innerText = questionData.text;

    const optionsContainer = document.getElementById("options");
    optionsContainer.innerHTML = "";

    Object.keys(questionData.options).forEach(letter => {
        const option = document.createElement("div");
        option.className = "option";
        option.innerText = questionData.options[letter];
        option.onclick = () => selectAnswer(letter, option);
        optionsContainer.appendChild(option);
    });

    document.getElementById("next-button").disabled = true;
}

function selectAnswer(letter, optionElement) {
    document.querySelectorAll(".option").forEach(opt => opt.classList.remove("selected"));
    optionElement.classList.add("selected");
    answers[letter]++;
    document.getElementById("next-button").disabled = false;
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion < questions.length) {
        loadQuestion();
    } else {
        showResult();
    }
}

function showResult() {
    document.getElementById("quiz-screen").style.display = "none";
    document.getElementById("result-screen").style.display = "block";

    let resultType = Object.keys(answers).reduce((a, b) => answers[a] > answers[b] ? a : b);
    document.getElementById("result-text").innerText = results[resultType];
}

function restartQuiz() {
    currentQuestion = 0;
    answers = { A: 0, B: 0, C: 0, D: 0 };
    document.getElementById("result-screen").style.display = "none";
    document.getElementById("start-screen").style.display = "block";
}